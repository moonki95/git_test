(function ($) {
	"use strict",
	//Nice Select
	$(document).ready(function () {
		$('select').niceSelect();
	});
	
}(jQuery));
