package bbs;

public class Bbs {
	private int bbsID;
	private String bbsTitle;
	private String userID;
	private String bbsDate;
	private String bbsContent;
	private String bbsDeadline;
	private int bbsYES;
	private int bbsNO;
	private int bbsAvailable;
	private int bbsVOTE;
	private int bbsView;
	
	
	public String getBbsDeadline() {
		return bbsDeadline;
	}
	public void setBbsDeadline(String bbsDeadline) {
		this.bbsDeadline = bbsDeadline;
	}
	public int getBbsYES() {
		return bbsYES;
	}
	public void setBbsYES(int bbsYES) {
		this.bbsYES = bbsYES;
	}
	public int getBbsNO() {
		return bbsNO;
	}
	public void setBbsNO(int bbsNO) {
		this.bbsNO = bbsNO;
	}
	public int getBbsVOTE() {
		return bbsVOTE;
	}
	public void setBbsVOTE(int bbsVOTE) {
		this.bbsVOTE = bbsVOTE;
	}
	public int getBbsView() {
		return bbsView;
	}
	public void setBbsView(int bbsView) {
		this.bbsView = bbsView;
	}
	public int getBbsID() {
		return bbsID;
	}
	public void setBbsID(int bbsID) {
		this.bbsID = bbsID;
	}
	public String getBbsTitle() {
		return bbsTitle;
	}
	public void setBbsTitle(String bbsTitle) {
		this.bbsTitle = bbsTitle;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getBbsDate() {
		return bbsDate;
	}
	public void setBbsDate(String bbsDate) {
		this.bbsDate = bbsDate;
	}
	public String getBbsContent() {
		return bbsContent;
	}
	public void setBbsContent(String bbsContent) {
		this.bbsContent = bbsContent;
	}
	public int getBbsAvailable() {
		return bbsAvailable;
	}
	public void setBbsAvailable(int bbsAvailable) {
		this.bbsAvailable = bbsAvailable;
	}
	
}
